import { useRouter } from 'next/router'
import Document from './_document';

export default function Home() {
  return (
    <p className="text-center text-danger">There is no Messages Recevied!</p>
  );
}
